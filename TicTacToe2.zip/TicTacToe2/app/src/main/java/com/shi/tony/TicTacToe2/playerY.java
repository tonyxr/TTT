package com.shi.tony.TicTacToe2;

/**
 * Created by 301195 on 12/8/17.
 */

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

    public class playerY extends TicTacToe
    {
        public boolean YWin()
        {
            int ScoreX = 0;
            int StepTaken = 0;
            boolean YWin = false;
            /**
            if (TicTacToe.TicTacToeBoardView.IsOWinner())
            {
                YWin = true;
                ScoreX +=1;
                return true;
            }
            else
            {
                return false;
            }
             **/
            return true;
        }
    }
