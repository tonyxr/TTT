package com.shi.tony.TicTacToe2;

/**
 * Created by 301195 on 12/6/17.
 */
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;


public class TicTacToeBoard extends Activity{


    private class TicTacToeBoardView extends View {
        TicTacToeBoardView ticTacToeBoardView;

        /**
         * public TicTacToeBoardView(TicTacToeBoardView ticTacToeBoardView) {
         * super(TicTacToeBoardView);
         * }
         **/

        public void onCreate(Bundle savedInstanceState) {
            ticTacToeBoardView.onCreate(savedInstanceState);
            //ticTacToeBoardView = new TicTacToeBoardView(this);
            setContentView(ticTacToeBoardView);
        }

        private String board[][] = {{"", "", ""}, {"", "", ""}, {"", "", ""}};  // tic tac toe board
        private String playerTurn = "x";                                // whose turn is it "x" or "o"
        private boolean XIsWinner = false;                              // did x win?
        private boolean OIsWinner = false;

        public TicTacToeBoardView(Context context) {
            super(context);
        }
    }

}
