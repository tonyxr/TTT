
package com.shi.tony.TicTacToe2;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
/**
 * Created by 301195 on 12/8/17.
 * if statement need to be rewritten
 */


public class playerX extends TicTacToe
{
        /**
        public boolean XWin()
        {
            int ScoreX = 0;
            int StepTaken = 0;
            boolean XWin = false;

            if (TicTacToe.TicTacToeBoardView.IsXWinner())
            {
                XWin = true;
                ScoreX +=1;
                return true;
            }
            else
            {
                return false;
            }

            return true;
        }
         **/
}
