package com.shi.tony.TicTacToe2;

/**
 * Created by 301195 on 12/6/17.
 */
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;


public class TicTacToeBoard extends Activity{


    private class TicTacToeBoardView extends View {
        TicTacToeBoardView ticTacToeBoardView;
        Paint paint = new Paint();
        public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        paint.setStrokeWidth(3);
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.STROKE);

        // draw tic tac toe board
        // vertical lines
        paint.setColor(Color.BLUE);
        canvas.drawLine(100, 0, 100, 300, paint);
        paint.setColor(Color.RED);
        canvas.drawLine(200, 0, 200, 300, paint);
        paint.setColor(Color.BLACK);
        canvas.drawLine(0, 100, 300, 100, paint);
        paint.setColor(Color.YELLOW);
        canvas.drawLine(0, 200, 300, 200, paint);
 }

        public void onCreate(Bundle savedInstanceState) {
            ticTacToeBoardView.onCreate(savedInstanceState);
            //ticTacToeBoardView = new TicTacToeBoardView(this);
            setContentView(ticTacToeBoardView);
        }

        private String board[][] = {{"", "", ""}, {"", "", ""}, {"", "", ""}};  // tic tac toe board
        private String playerTurn = "x";                                // whose turn is it "x" or "o"
        private boolean XIsWinner = false;                              // did x win?
        private boolean OIsWinner = false;

        public TicTacToeBoardView(Context context) {
            super(context);
        }
    }
}
